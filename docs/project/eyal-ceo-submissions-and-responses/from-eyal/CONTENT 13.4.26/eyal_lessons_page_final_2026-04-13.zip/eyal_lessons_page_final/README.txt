Package: שיעורי נגינה בדיג'רידו - תוכן סופי
Project: eyalamit.co.il
Page: שיעורי נגינה בדיג'רידו
Status: Final canonical content for site builder
Date: 2026-04-13

Files:
- lessons-page_final_he.md : final full page copy in Hebrew with internal links placeholders/HTML anchors
- lessons-page_sections_he.md : same content split by sections for builder convenience
- notes_for_builder.txt : implementation notes for links and CTA
