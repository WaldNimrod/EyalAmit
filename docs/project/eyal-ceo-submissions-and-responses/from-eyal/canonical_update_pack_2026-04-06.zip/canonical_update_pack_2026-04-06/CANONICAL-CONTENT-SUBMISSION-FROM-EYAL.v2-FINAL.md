# פורמט קנוני להגשת תוכן מאייל - v2 FINAL

מסמך זה מחליף את גרסת ההגשה הקודמת כפורמט העבודה המחייב למסירת תוכן לצוות הפיתוח, לצוות התוכן ולסוכנים.

## 1. עקרונות על
1. עץ האתר הנעול הוא מקור האמת ל-IA, ל-`pageId`, ל-`slug` ול-`templateId`.
2. כל עמוד מוגש לפי התבנית שהוגדרה לו בעץ האתר בלבד.
3. אסור להמציא `pageId` חדש, לשנות `slug`, או לשנות `templateId` ללא שינוי מאושר בקאנון.
4. קובץ עמוד וקובצי אינסטנסים מוגשים בנפרד.
5. `extensions` מותר רק כאשר אין פתרון בשדות הרשמיים.

## 2. שדות זהות ותפעול - חובה בכל קובץ עמוד
כל קובץ תוכן, ב-Markdown, JSON או Word, חייב לכלול:
- `pageId`
- `slug`
- `templateId`
- `respondent`
- `exportTimestamp`
- `contentStatus`

ערכים מורשים ל-`contentStatus`:
- `draft`
- `reviewed`
- `approved`
- `ready-for-dev`

שדות תפעוליים מומלצים:
- `sourceNotes`
- `searchIntent`
- `ctaTargets`
- `driveRefs`

## 3. פורמט שמות קבצים
```text
YYYY-MM-DD--<pageId>--content--from-eyal.md
YYYY-MM-DD--<pageId>--content--from-eyal.json
YYYY-MM-DD--instances--<kind>--from-eyal.json
```

## 4. Markdown - פורמט מחייב
כל מסמך Markdown יתחיל ב-YAML Front Matter:

```yaml
---
pageId: st-svc-treatment
slug: treatment
templateId: tpl-service
respondent: Eyal Amit
exportTimestamp: 2026-04-10
contentStatus: approved
sourceNotes:
  - ניסוח חדש על בסיס מסמך הפרויקט
driveRefs: []
ctaTargets: []
---
```

לאחר מכן, כל שדה יוצג כך:

```markdown
## field:<field_id>
תוכן השדה
```

מותר להשתמש ב-Markdown פנימי בתוך תוכן השדה.

## 5. JSON - פורמט מחייב
### עמוד בודד
```json
{
  "schemaVersion": 2,
  "exportType": "eyal-page-content-intake",
  "respondent": "Eyal Amit",
  "exportTimestamp": "2026-04-10T12:00:00.000Z",
  "pageId": "st-home",
  "slug": "home",
  "templateId": "tpl-home",
  "contentStatus": "approved",
  "sourceNotes": ["..."],
  "searchIntent": {
    "intentType": "informational",
    "primaryTopicHe": "..."
  },
  "ctaTargets": [],
  "fieldValues": {}
}
```

### אצווה
```json
{
  "schemaVersion": 2,
  "exportType": "eyal-content-pack-batch",
  "deliveredVia": "google-drive:from-eyal",
  "exportTimestamp": "2026-04-10T12:00:00.000Z",
  "respondent": "Eyal Amit",
  "pages": []
}
```

## 6. מודל אינסטנסים - חובה להפריד
אינסטנסים כמו FAQ, Gallery, Testimonial, Media יוגשו בקובצי JSON ייעודיים נפרדים.

### FAQ
```json
{
  "schemaVersion": 2,
  "exportType": "eyal-instances-faq",
  "instances": [
    {
      "groupHe": "טיפול",
      "questionHe": "...",
      "answerHe": "...",
      "targetPageIds": ["st-home", "st-svc-treatment"],
      "driveRefs": []
    }
  ]
}
```

### Gallery
```json
{
  "schemaVersion": 2,
  "exportType": "eyal-instances-gallery",
  "instances": [
    {
      "titleHe": "כותרת תמונה",
      "captionHe": "תיאור קצר",
      "targetPageIds": ["st-book-kushi"],
      "driveRefs": ["file-name.jpg"]
    }
  ]
}
```

### Testimonial / Media
```json
{
  "schemaVersion": 2,
  "exportType": "eyal-instances-testimonial",
  "instances": [
    {
      "titleHe": "כותרת קצרה",
      "quoteHe": "ציטוט או תקציר",
      "attributionHe": "שם / מקור",
      "linkUrl": "https://…",
      "targetPageIds": ["st-media"],
      "driveRefs": []
    }
  ]
}
```

## 7. תבנית חדשה מחייבת - tpl-book-detail
דפי ספר בודדים לא יוגשו עוד תחת `tpl-secondary`.

### שדות tpl-book-detail
- `title`
- `summary`
- `body`
- `excerpt_heading`
- `excerpt_body`
- `edition_note`
- `purchase_primary_label`
- `purchase_primary_url`
- `purchase_secondary_label`
- `purchase_secondary_url`
- `gallery_heading`
- `gallery_intro`
- `cta_footer`
- `media_notes`

## 8. מיפוי מחייב לדפי ספר
יש לעדכן את עץ האתר כך שהעמודים הבאים יעברו ל-`tpl-book-detail`:
- `st-book-tsva`
- `st-book-kushi`
- `st-book-vekatavt`

## 9. CTA - כלל עבודה מחייב
אם יש CTA בעמוד, יש למסור:
- טקסט CTA בשדה התבנית
- יעד CTA ב-`ctaTargets` ברמת הקובץ

דוגמה:
```json
"ctaTargets": [
  {
    "fieldId": "purchase_primary_label",
    "targetType": "external_url",
    "targetValue": "https://example.com"
  }
]
```

## 10. sourceNotes - כלל עבודה מחייב
יש לציין מאיפה הגיע התוכן:
- ניסוח חדש
- ניסוח מבוסס עמוד קיים
- נוסח שעובד מקטעים קיימים
- מדיה/נכסים שמגיעים מ-Drive

## 11. מדיניות שימוש ב-extensions
`extensions` מותר רק במקרים הבאים:
1. הערה למפתח שאין לה שדה רשמי
2. הנחיית מיקום בלוק זמנית
3. תיעוד חריג חד-פעמי

אין להשתמש ב-`extensions` כתחליף לשדה תוכן חסר שחוזר על עצמו במספר עמודים.

## 12. Word / Google Docs
אם נמסר Word/Google Doc, יש לשמור בדיוק את אותם מזהים בראש המסמך:
- `pageId`
- `slug`
- `templateId`
- `contentStatus`

ומומלץ מאוד לצרף קובץ Markdown או JSON מקביל.

## 13. היישום המחייב
מעת אישור מסמך זה:
1. זהו הפורמט המחייב להגשת כל עמוד.
2. POC ראשון לתהליך: `st-book-kushi`.
3. כל עמוד נוסף יוגש לפי אותו מבנה בדיוק.
